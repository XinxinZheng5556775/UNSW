# 6080-Exam-Practice
Mini games I made to practice for COMP6080 final exam. BTW, ChatGPT helped me generate some of the game list!
Why using JS? Because I'm too ceebs to use TS :>

# Game list
- 2048
- Connect Four
- Memory Game
- Tic-Tac-Toe
- Wordle
